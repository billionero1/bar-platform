import React from 'react';

const AdminPreparations: React.FC = () => {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Заготовки (Модератор)</h1>
      <p className="mt-2">Тут будет список заготовок и создание новых рецептов.</p>
    </div>
  );
};

export default AdminPreparations;