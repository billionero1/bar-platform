import React from 'react';
import { useNavigate } from 'react-router-dom';

const Calculate: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="p-4">
      <button onClick={() => navigate(-1)} className="text-blue-500 mb-4">&larr; Назад</button>
      <h1 className="text-xl font-bold">Расчёт заготовок</h1>
      <p className="text-gray-600 mt-2">Здесь будет выбор заготовки и пересчёт объёма.</p>
    </div>
  );
};

export default Calculate;