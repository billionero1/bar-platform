
export default function TeamPage() {
  return <div className="p-4">Команда / сотрудники</div>;
}
