import React from 'react';

const AdminIngredients: React.FC = () => {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Ингредиенты (Модератор)</h1>
      <p className="mt-2">Тут будет список ингредиентов и кнопка добавить.</p>
    </div>
  );
};

export default AdminIngredients;