
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';

export default function CalculationPage() {
  const navigate = useNavigate();
  const [volume, setVolume] = useState(1.3);

  return (
    <div className="p-4">
      <button onClick={() => navigate(-1)} className="text-lg mb-4">←</button>
      <input
        value={volume}
        onChange={e => setVolume(parseFloat(e.target.value))}
        className="w-full border border-gray-300 rounded p-2 mb-4"
        placeholder="Desired Volume"
      />
      <ul>
        <li className="mb-2">Fructose: {(volume * 471.2).toFixed(1)} g</li>
        <li className="mb-2">Water: {(volume * 624.2).toFixed(1)} ml</li>
      </ul>
    </div>
  );
}
