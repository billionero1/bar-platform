import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function normalizePhone(input: string) {
  const digits = input.replace(/\D/g, '');
  return digits.startsWith('8') ? '7' + digits.slice(1) : digits;
}

function formatPhone(value: string) {
  const digits = value.replace(/\D/g, '').replace(/^8/, '7');
  let result = '+7 ';
  if (digits.length > 1) result += digits.slice(1, 4);
  if (digits.length >= 4) result += ' ' + digits.slice(4, 7);
  if (digits.length >= 7) result += ' ' + digits.slice(7, 9);
  if (digits.length >= 9) result += ' ' + digits.slice(9, 11);
  return result.trim();
}

export default function Login() {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async () => {
    const res = await fetch(`${import.meta.env.VITE_API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone: normalizePhone(phone), password })
    });

    const data = await res.json();
    if (res.ok) {
      localStorage.setItem('token', data.token);
      if (data.role === 'moderator') {
        navigate('/main');
      } else {
        navigate('/main');
      }

    } else {
      alert(data.error || 'Ошибка входа');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow w-full max-w-md">
        <h1 className="text-2xl font-bold mb-4 text-center">Вход</h1>

        <input
          className="w-full border p-2 mb-2"
          placeholder="Телефон"
          value={phone}
          onChange={(e) => {
            const raw = e.target.value.replace(/\D/g, '');
            setPhone(formatPhone(raw));
          }}
        />

        <div className="relative mb-4">
          <input
            className="w-full border p-2 pr-16"
            type={showPassword ? 'text' : 'password'}
            placeholder="Пароль"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button
            type="button"
            className="absolute right-2 top-2 text-sm text-blue-600"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? 'Скрыть' : 'Показать'}
          </button>
        </div>

        <button
          className="w-full bg-blue-600 text-white py-2 rounded"
          onClick={handleLogin}
        >
          Войти
        </button>

        <p className="text-center mt-4 text-sm">
          Я менеджер? <a className="text-blue-600 underline" href="/register">Создать заведение</a>
        </p>
      </div>
    </div>
  );
}
