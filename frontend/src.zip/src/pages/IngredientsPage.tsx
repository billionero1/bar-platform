
import { useState } from 'react';

export default function IngredientsPage() {
  const [ingredients, setIngredients] = useState(['Fructose', 'Lime Juice', 'Sugar']);
  const [input, setInput] = useState('');

  const add = () => {
    if (input.trim()) {
      setIngredients([...ingredients, input.trim()]);
      setInput('');
    }
  };

  return (
    <div className="p-4">
      <input
        placeholder="New ingredient"
        value={input}
        onChange={e => setInput(e.target.value)}
        className="w-full border border-gray-300 rounded p-2 mb-2"
      />
      <button onClick={add} className="text-blue-600 text-sm mb-4">+ ADD INGREDIENT</button>
      <ul>
        {ingredients.map((i, idx) => (
          <li key={idx} className="py-2 border-b">{i}</li>
        ))}
      </ul>
    </div>
  );
}
