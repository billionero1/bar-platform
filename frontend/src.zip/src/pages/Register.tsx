import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function formatPhone(value: string) {
  const digits = value.replace(/\D/g, '').replace(/^8/, '7');
  let result = '+7 ';
  if (digits.length > 1) result += digits.slice(1, 4);
  if (digits.length >= 4) result += ' ' + digits.slice(4, 7);
  if (digits.length >= 7) result += ' ' + digits.slice(7, 9);
  if (digits.length >= 9) result += ' ' + digits.slice(9, 11);
  return result.trim();
}

function normalizePhone(input: string) {
  const digits = input.replace(/\D/g, '');
  return digits.startsWith('8') ? '7' + digits.slice(1) : digits;
}

export default function Register() {
  const [establishmentName, setEstablishmentName] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const navigate = useNavigate();

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '');
    setPhone(formatPhone(raw));
  };

  const handleRegister = async () => {
    const res = await fetch(`${import.meta.env.VITE_API_URL}/auth/register-manager`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        establishmentName,
        name,
        phone: normalizePhone(phone),
        password
      })
    });

    const data = await res.json();
    if (res.ok) {
      navigate('/login');
    } else {
      alert(data.error || 'Ошибка регистрации');
    }
  };

  const passwordsMatch = password === confirm && password.length >= 6;

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow w-full max-w-md">
        <h1 className="text-2xl font-bold mb-4 text-center">Регистрация менеджера</h1>
        <input className="w-full border p-2 mb-2" placeholder="Название заведения" value={establishmentName} onChange={(e) => setEstablishmentName(e.target.value)} />
        <input className="w-full border p-2 mb-2" placeholder="Имя" value={name} onChange={(e) => setName(e.target.value)} />
        <input className="w-full border p-2 mb-2" placeholder="Телефон" value={phone} onChange={handlePhoneChange} />
        
        <div className="relative mb-2">
          <input className="w-full border p-2 pr-16" type={showPassword ? 'text' : 'password'} placeholder="Пароль" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button type="button" className="absolute right-2 top-2 text-sm text-blue-600" onClick={() => setShowPassword(!showPassword)}>
            {showPassword ? 'Скрыть' : 'Показать'}
          </button>
        </div>

        <div className="relative mb-4">
          <input className="w-full border p-2 pr-16" type={showConfirm ? 'text' : 'password'} placeholder="Повторите пароль" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          <button type="button" className="absolute right-2 top-2 text-sm text-blue-600" onClick={() => setShowConfirm(!showConfirm)}>
            {showConfirm ? 'Скрыть' : 'Показать'}
          </button>
        </div>

        <button className={`w-full py-2 rounded text-white ${passwordsMatch ? 'bg-blue-600' : 'bg-gray-400 cursor-not-allowed'}`} disabled={!passwordsMatch} onClick={handleRegister}>
          Зарегистрироваться
        </button>
      </div>
    </div>
  );
}
