import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function MainPage() {
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  const preparations = [
    'Fructose Syrup',
    'Lime Cordial',
    'Ginger Mix',
    'Sugar Syrup',
    'Spicy Base',
  ];

  const filtered = preparations.filter(p =>
    p.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4">
      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search preparations"
        className="w-full p-2 mb-4 border border-gray-300 rounded"
      />
      <ul>
        {filtered.map((prep, i) => (
          <li
            key={i}
            onClick={() => navigate(`/calculate/${encodeURIComponent(prep)}`)}
            className="py-3 border-b text-base text-gray-800"
          >
            {prep}
          </li>
        ))}
      </ul>
    </div>
  );
}
