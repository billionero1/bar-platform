import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

export default function CalculationPage() {
  const { prep } = useParams<{ prep: string }>();
  const [qty, setQty] = useState(1);
  const [ingredients, setIngredients] = useState<{ name: string, amount: number }[]>([]);
  const nav = useNavigate();

  useEffect(() => {
    fetch(`${import.meta.env.VITE_API_URL}/preparations/${encodeURIComponent(prep)}`, {
      headers: { Authorization: 'Bearer ' + localStorage.getItem('token') }
    })
      .then(r => r.json())
      .then(data => setIngredients(data.ingredients));
  }, [prep]);

  const scaled = ingredients.map(i => ({
    ...i,
    amount: i.amount * qty
  }));

  return (
    <div className="p-4">
      <button onClick={() => nav(-1)} className="mb-4">← Назад</button>
      <h2 className="text-xl font-semibold mb-2">{prep}</h2>
      <div className="mb-4">
        <label>Кол-во (литры): </label>
        <input type="number" min="0" value={qty}
               onChange={e => setQty(+e.target.value)}
               className="border p-1 w-20" />
      </div>
      <ul>
        {scaled.map((i, idx) => (
          <li key={idx}>
            {i.name}: {i.amount.toFixed(2)}
          </li>
        ))}
      </ul>
    </div>
  );
}
