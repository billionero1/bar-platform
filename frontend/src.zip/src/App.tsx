import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./pages/AuthContext";
import Login from "./pages/Login";
import Register from "./pages/Register";
import MainPage from "./pages/MainPage";
import IngredientsPage from "./pages/IngredientsPage";
import CreatePreparationPage from "./pages/Preparations";
import CalculationPage from "./pages/CalculationPage";
import TeamPage from "./pages/TeamPage";

function ProtectedRoute({ children, role }: { children: JSX.Element; role?: string }) {
  const { user } = useAuth();

  if (!user) return <Navigate to="/login" />;

  if (role && user.role !== role) return <Navigate to="/" />;

  return children;
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={
            <ProtectedRoute>
              <MainPage />
            </ProtectedRoute>
          } />
          <Route path="/ingredients" element={
            <ProtectedRoute role="manager">
              <IngredientsPage />
            </ProtectedRoute>
          } />
          <Route path="/preparations" element={
            <ProtectedRoute role="manager">
              <CreatePreparationPage />
            </ProtectedRoute>
          } />
          <Route path="/calculate/:id" element={
            <ProtectedRoute>
              <CalculationPage />
            </ProtectedRoute>
          } />
          <Route path="/team" element={
            <ProtectedRoute role="manager">
              <TeamPage />
            </ProtectedRoute>
          } />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
