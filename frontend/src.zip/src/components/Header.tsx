import { useNavigate } from 'react-router-dom';

export default function Header({ isManager }: { isManager: boolean }) {
  const nav = useNavigate();

  return (
    <header className="flex items-center justify-between p-4 border-b border-gray-200 bg-white">
      <h1 className="text-lg font-semibold">Preparations</h1>
      {isManager && (
        <button onClick={() => nav('/menu')} className="text-3xl text-gray-800">☰</button>
      )}
    </header>
  );
}
